import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class CarpetCalculator implements Calculatable{
    private float pricePerSquareFoot;
    private Float installationFee;
    private float total;
    private String totalCost;
    private float taxFee;
    private float percentDiscount;
    private float perDiscTotal;
    private int widthOfRoom;
    private int lengthOfRoom;
    private Room addRoom;
    private ArrayList<Room> room;
    private int area;

    public CarpetCalculator(float pricePerSquareFoot) {
        this.room = new ArrayList<Room>();
        this.pricePerSquareFoot = pricePerSquareFoot;
    }
    public CarpetCalculator(float pricePerSquareFoot, float installationFee) {
        this.room = new ArrayList<Room>();
        this.pricePerSquareFoot = pricePerSquareFoot;
        this.installationFee = installationFee;
    }
    public void addRoom(Room room) {
        this.room.add(room);
    }
    public void addPercentDiscount(float percentDiscount) {
        this.percentDiscount = percentDiscount;
        this.perDiscTotal = perDiscTotal;
        perDiscTotal = (this.total - (percentDiscount * total));


    }
    public float getTotalCost() {
        for (Room room : room) {
            total = (total + pricePerSquareFoot * room.getLengthOfRoom() * room.getWidthOfRoom());
        }
        if (installationFee != null) {
            total = total + installationFee;
        }
        return this.total;
    }



    public float getTaxFee() {
        this.taxFee = taxFee;
        taxFee = this.total * this.percentDiscount;
        return this.taxFee;
    }

    public String moneyAlt(float number) {
        NumberFormat n = NumberFormat.getCurrencyInstance(Locale.US);
        String s = n.format(number);
        return s;
    }

}
