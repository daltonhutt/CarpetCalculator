public class Room {

    private int widthOfRoom;
    private int lengthOfRoom;

    public Room (int widthOfRoom, int lengthOfRoom) {
        this.lengthOfRoom = lengthOfRoom;
        this.widthOfRoom = widthOfRoom;
    }
    public int getWidthOfRoom() {
        return this.widthOfRoom;
    }

    public int getLengthOfRoom() {
        return this.lengthOfRoom;
    }

}
