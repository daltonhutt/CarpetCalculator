public interface Calculatable {
    void addRoom(Room room);
    float getTotalCost();
    void addPercentDiscount(float percentDiscount);

}
